package com.sapient.filereading.constant;

public class FileConstant {
	
	public static final String FILE_NAME= "c:\\sample.csv";
	public static final String COMMA_SEPARATOr= ",";

}
