package com.sapient.filereading.impl;

import java.util.List;

import com.sapient.filereading.endpoint.FileReader;
import com.sapient.filereading.model.CurrencyDto;

public class TXTReader implements FileReader {

	@Override
	public List<CurrencyDto> getFileReaderType(String fileType) {
		// TODO Auto-generated method stub
		return null;
	}

}
