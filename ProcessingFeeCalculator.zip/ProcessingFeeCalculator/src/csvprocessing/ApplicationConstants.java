package csvprocessing;

/**
 * 
 * @author jasbirsingh
 *
 */
public class ApplicationConstants {

	public static final String CSV_SEPARATOR = ",";
	public static final String FILE_PATH = "e:\\sample.csv";
	
}
