package com.sapient.processingfeecalculator.util;

public class ProcessingFeeConstants {

	public static final String CSV_DELIM = "\t";
	public static final String BUY = "BUY";
	public static final String SELL = "SELL";
	public static final String DEPOSIT = "DEPOSIT";
	public static final String WITHDRAW = "WITHDRAW";
}
