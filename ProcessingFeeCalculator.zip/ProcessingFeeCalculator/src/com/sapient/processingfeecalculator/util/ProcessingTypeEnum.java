package com.sapient.processingfeecalculator.util;

public enum ProcessingTypeEnum {
	INTRADAY,NORMAL
}
