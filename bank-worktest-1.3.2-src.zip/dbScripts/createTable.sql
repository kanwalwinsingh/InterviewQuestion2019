create table ACCOUNT_DETAILS (
	account_id integer not null, 
	account_ref varchar(255) not null, 
	balance DECIMAL(20, 2) not null, 
	currency varchar(5) not null,
	creation_date timestamp not null,
	updation_date timestamp,
	version integer not null,
	primary key (account_id),
	UNIQUE KEY account_ref_UNIQUE (account_ref) 
	);

create table transactions (
	transaction_id integer not null, 
	transaction_ref varchar(255) not null, 
	type varchar(55), 
	transaction_date timestamp not null,
	primary key (transaction_id),
	UNIQUE KEY transaction_ref_UNIQUE (transaction_ref)
	);

create table transaction_legs (
	transaction_leg_id integer not null, 
	account_ref varchar(255) not null, 
	amount DECIMAL(20, 2) not null, 
	currency varchar(5) not null,
	transaction_id integer not null, 
	foreign key (transaction_id) REFERENCES transactions (transaction_id), 
	primary key (transaction_leg_id)
	);