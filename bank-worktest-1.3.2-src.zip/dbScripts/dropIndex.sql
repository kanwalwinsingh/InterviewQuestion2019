DROP INDEX account_ref_INDEX;

DROP INDEX transaction_ref_INDEX;

DROP INDEX transaction_id_INDEX;