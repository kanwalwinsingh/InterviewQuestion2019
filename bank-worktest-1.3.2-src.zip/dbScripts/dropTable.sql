drop table ACCOUNT_DETAILS;
drop table transactions;
drop table transaction_legs;