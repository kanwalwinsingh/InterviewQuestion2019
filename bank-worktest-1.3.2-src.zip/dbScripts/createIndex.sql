CREATE INDEX account_ref_INDEX on ACCOUNT_DETAILS(account_ref);

CREATE INDEX transaction_ref_INDEX on transactions(transaction_ref);

CREATE INDEX transaction_id_INDEX on transaction_legs(transaction_id);