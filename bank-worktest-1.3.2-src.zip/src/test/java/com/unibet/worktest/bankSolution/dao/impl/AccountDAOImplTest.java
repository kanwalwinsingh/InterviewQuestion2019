/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.PersistenceException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.unibet.worktest.bankSolution.controller.BankController;
import com.unibet.worktest.bankSolution.entity.AccountBO;
import com.unibet.worktest.bankSolution.exception.BankDataAccessException;
import com.unibet.worktest.bankSolution.repositories.AccountRepository;

/**
 * Test class for {@link AccountDAOImpl}
 *
 * @author mohit100p29
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = { BankController.class })
public class AccountDAOImplTest {

	private static final String CASH_ACCOUNT_1 = "cash:1:EUR";
	private static final String TEST_EXCEPTION_TEXT = "Test Exception";
	private static final String EUR_CURRENCY = "EUR";

	private AccountBO account;

	@Mock
	private AccountRepository accountRepository;

	@InjectMocks
	private AccountDAOImpl accountDAOImpl;

	@Before
	public void setUp() throws Exception {
		account = new AccountBO(CASH_ACCOUNT_1, BigDecimal.TEN, EUR_CURRENCY,
				Calendar.getInstance());
	}

	@Test
	public void saveAccountTest() throws Exception {

		accountDAOImpl.saveAccount(account);
		Mockito.verify(accountRepository).save(account);
	}

	@Test(expected = BankDataAccessException.class)
	public void saveAccountBankDataAccessExceptionTest() throws Exception {

		Mockito.when(accountRepository.save(Matchers.any(AccountBO.class)))
		.thenThrow(new PersistenceException(TEST_EXCEPTION_TEXT));

		accountDAOImpl.saveAccount(account);
	}

	@Test
	public void findByAccountRefTest() throws Exception {

		accountDAOImpl.findByAccountRef(CASH_ACCOUNT_1);
		Mockito.verify(accountRepository)
		.findByAccountReference(CASH_ACCOUNT_1);
	}

	@Test(expected = BankDataAccessException.class)
	public void findByAccountRefBankDataAccessExceptionTest() throws Exception {

		Mockito.when(accountRepository.findByAccountReference(Matchers.any()))
		.thenThrow(new PersistenceException(TEST_EXCEPTION_TEXT));

		accountDAOImpl.findByAccountRef(CASH_ACCOUNT_1);
	}

	@Test
	public void updateAccountsTest() throws Exception {

		List<AccountBO> accounts = new ArrayList<AccountBO>();
		accounts.add(account);
		accountDAOImpl.updateAccounts(accounts);
		Mockito.verify(accountRepository).save(accounts);
	}

	@SuppressWarnings("unchecked")
	@Test(expected = BankDataAccessException.class)
	public void updateAccountsBankDataAccessExceptionTest() throws Exception {

		List<AccountBO> accounts = new ArrayList<AccountBO>();
		accounts.add(account);

		Mockito.when(accountRepository.save(Matchers.anyList())).thenThrow(
				new PersistenceException(TEST_EXCEPTION_TEXT));

		accountDAOImpl.updateAccounts(accounts);
	}

}
