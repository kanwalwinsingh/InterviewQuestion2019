/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.PersistenceException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.unibet.worktest.bankSolution.controller.BankController;
import com.unibet.worktest.bankSolution.entity.TransactionBO;
import com.unibet.worktest.bankSolution.entity.TransactionLegBO;
import com.unibet.worktest.bankSolution.exception.BankDataAccessException;
import com.unibet.worktest.bankSolution.repositories.TransactionRepository;

/**
 * Test class for {@link TransactionDAOImpl}
 *
 * @author mohit100p29
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = { BankController.class })
public class TransactionDAOImplTest {

	private static final String CASH_ACCOUNT_1 = "cash:1:EUR";
	private static final String DEPOSIT_ACCOUNT_1 = "deposit:1:EUR";
	private static final String TEST_EXCEPTION_TEXT = "Test Exception";
	private static final String EUR_CURRENCY = "EUR";
	private static final BigDecimal BALANCE_AMOUNT = new BigDecimal("100");
	private static final String TRANSACTION_REFERENCE = "tx1";
	private static final String EMPTY_STRING = "";

	private TransactionBO transactionBO;

	@Mock
	private TransactionRepository transactionRepository;

	@InjectMocks
	private TransactionDAOImpl transactionDAOImpl;

	@Before
	public void setUp() throws Exception {
		transactionBO = new TransactionBO(TRANSACTION_REFERENCE, "type",
				Calendar.getInstance());

		List<TransactionLegBO> legs = new ArrayList<>();
		legs.add(new TransactionLegBO(CASH_ACCOUNT_1, BigDecimal.TEN.negate(),
				EUR_CURRENCY, transactionBO));
		legs.add(new TransactionLegBO(DEPOSIT_ACCOUNT_1, BigDecimal.TEN,
				EUR_CURRENCY, transactionBO));
	}

	@Test
	public void saveTransactionTest() throws Exception {

		transactionDAOImpl.saveTransaction(transactionBO);
		Mockito.verify(transactionRepository).save(transactionBO);
	}

	@Test(expected = BankDataAccessException.class)
	public void saveTransactionBankDataAccessExceptionTest() throws Exception {

		Mockito.when(
				transactionRepository.save(Matchers.any(TransactionBO.class)))
				.thenThrow(new PersistenceException(TEST_EXCEPTION_TEXT));

		transactionDAOImpl.saveTransaction(transactionBO);
	}

	@Test
	public void findTransactionsByAccountRefTest() throws Exception {

		transactionDAOImpl.findTransactionsByAccountRef(CASH_ACCOUNT_1);
		Mockito.verify(transactionRepository).findTransactionsByAccountRef(
				CASH_ACCOUNT_1);
	}

	@Test(expected = BankDataAccessException.class)
	public void findTransactionsByAccountRefBankDataAccessExceptionTest()
			throws Exception {

		Mockito.when(
				transactionRepository.findTransactionsByAccountRef(Matchers
						.any())).thenThrow(
								new PersistenceException(TEST_EXCEPTION_TEXT));

		transactionDAOImpl.findTransactionsByAccountRef(CASH_ACCOUNT_1);
	}

	@Test
	public void findTransactionsByReferenceTest() throws Exception {

		transactionDAOImpl.findTransactionsByReference(TRANSACTION_REFERENCE);
		Mockito.verify(transactionRepository).findTransactionsByReference(
				TRANSACTION_REFERENCE);
	}

	@Test(expected = BankDataAccessException.class)
	public void findTransactionsByReferenceBankDataAccessExceptionTest()
			throws Exception {

		Mockito.when(
				transactionRepository.findTransactionsByReference(Matchers
						.any())).thenThrow(
				new PersistenceException(TEST_EXCEPTION_TEXT));

		transactionDAOImpl.findTransactionsByReference(TRANSACTION_REFERENCE);
	}
}
