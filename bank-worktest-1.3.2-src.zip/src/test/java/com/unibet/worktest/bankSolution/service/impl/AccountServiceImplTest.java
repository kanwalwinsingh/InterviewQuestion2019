package com.unibet.worktest.bankSolution.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Currency;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.unibet.worktest.bank.AccountNotFoundException;
import com.unibet.worktest.bank.InfrastructureException;
import com.unibet.worktest.bank.Money;
import com.unibet.worktest.bankSolution.controller.BankController;
import com.unibet.worktest.bankSolution.dao.impl.AccountDAOImpl;
import com.unibet.worktest.bankSolution.entity.AccountBO;
import com.unibet.worktest.bankSolution.exception.BankDataAccessException;

/**
 * Test class for {@link AccountServiceImpl}
 *
 * @author mohit100p29
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = { BankController.class })
public class AccountServiceImplTest {

	private static final String CASH_ACCOUNT_1 = "cash:1:EUR";
	private static final String TEST_EXCEPTION_TEXT = "Test Exception";
	private static final String EUR_CURRENCY = "EUR";
	private static final BigDecimal BALANCE_AMOUNT = new BigDecimal("100");

	@Captor
	private ArgumentCaptor<AccountBO> accountCaptor;

	@Mock
	private AccountDAOImpl accountDAO;

	@InjectMocks
	private AccountServiceImpl accountService;

	@Test(expected = InfrastructureException.class)
	public void createAccountIllegalArgumentTest() throws Exception {
		accountService.createAccount(CASH_ACCOUNT_1, null);
	}

	@Test(expected = InfrastructureException.class)
	public void createAccountInfrastructureExceptionTest() throws Exception {

		Mockito.when(accountDAO.saveAccount(Matchers.any())).thenThrow(
				new BankDataAccessException(TEST_EXCEPTION_TEXT));
		accountService.createAccount(CASH_ACCOUNT_1, Money.euros("1000.00"));
	}

	@Test
	public void createAccountObjectTest() throws Exception {

		accountService.createAccount(CASH_ACCOUNT_1, Money.euros("1000.00"));
		Mockito.verify(accountDAO).saveAccount(accountCaptor.capture());
		AccountBO account = accountCaptor.getValue();

		assertNotNull(account);
		assertEquals(CASH_ACCOUNT_1, account.getAccountReference());
		assertEquals(new BigDecimal("1000.00"), account.getBalance());
		assertEquals(EUR_CURRENCY, account.getCurrency());
	}

	@Test(expected = AccountNotFoundException.class)
	public void getAccountBalanceAccountNotFoundExceptionTest()
			throws Exception {

		Mockito.when(accountDAO.findByAccountRef(Matchers.any())).thenReturn(
				Optional.empty());
		accountService.getAccountBalance(CASH_ACCOUNT_1);
	}

	@Test(expected = InfrastructureException.class)
	public void getAccountBalanceIllegalArgumentTest() throws Exception {

		accountService.getAccountBalance("");
	}

	@Test
	public void getAccountBalanceAccountTest() throws Exception {
		AccountBO account = new AccountBO(CASH_ACCOUNT_1, BALANCE_AMOUNT,
				EUR_CURRENCY, Calendar.getInstance());
		Mockito.when(accountDAO.findByAccountRef(CASH_ACCOUNT_1)).thenReturn(
				Optional.of(account));
		Money balance = accountService.getAccountBalance(CASH_ACCOUNT_1);

		assertNotNull(balance);
		assertEquals(BALANCE_AMOUNT, balance.getAmount());
		assertEquals(Currency.getInstance(EUR_CURRENCY), balance.getCurrency());
	}
}
