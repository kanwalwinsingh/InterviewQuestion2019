/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.unibet.worktest.bank.InfrastructureException;
import com.unibet.worktest.bank.Money;
import com.unibet.worktest.bank.Transaction;
import com.unibet.worktest.bank.TransferRequest;
import com.unibet.worktest.bankSolution.controller.BankController;
import com.unibet.worktest.bankSolution.dao.impl.AccountDAOImpl;
import com.unibet.worktest.bankSolution.dao.impl.TransactionDAOImpl;
import com.unibet.worktest.bankSolution.entity.AccountBO;
import com.unibet.worktest.bankSolution.entity.TransactionBO;
import com.unibet.worktest.bankSolution.entity.TransactionLegBO;
import com.unibet.worktest.bankSolution.exception.BankDataAccessException;

/**
 * Test class for {@link TransferServiceImpl}
 *
 * @author mohit100p29
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = { BankController.class })
public class TransferServiceImplTest {

	private static final String CASH_ACCOUNT_1 = "cash:1:EUR";
	private static final String DEPOSIT_ACCOUNT_1 = "deposit:1:EUR";
	private static final String TEST_EXCEPTION_TEXT = "Test Exception";
	private static final String EUR_CURRENCY = "EUR";
	private static final BigDecimal BALANCE_AMOUNT = new BigDecimal("100");
	private static final String TRANSACTION_REFERENCE = "tx1";
	private static final String EMPTY_STRING = "";

	private TransactionBO transactionBO;

	@Captor
	private ArgumentCaptor<TransactionBO> accountCaptor;

	@Mock
	private TransactionDAOImpl transactionDAO;

	@Mock
	private AccountDAOImpl accountDAO;

	@InjectMocks
	private TransferServiceImpl transferService;

	@Before
	public void setUp() {

		transactionBO = new TransactionBO(TRANSACTION_REFERENCE, "type",
				Calendar.getInstance());

		List<TransactionLegBO> legs = new ArrayList<>();
		legs.add(new TransactionLegBO(CASH_ACCOUNT_1, BigDecimal.TEN.negate(),
				EUR_CURRENCY, transactionBO));
		legs.add(new TransactionLegBO(DEPOSIT_ACCOUNT_1, BigDecimal.TEN,
				EUR_CURRENCY, transactionBO));

	}

	@Test(expected = InfrastructureException.class)
	public void transferFundsIllegalArgumentTest() throws Exception {

		transferService
				.transferFunds(TransferRequest.builder().reference(null)
						.account(CASH_ACCOUNT_1).amount(Money.euros("-5.00"))
						.account(DEPOSIT_ACCOUNT_1).amount(Money.euros("5.00"))
						.build());
	}

	@Test(expected = InfrastructureException.class)
	public void transferFundsInfrastructureExceptionTest() throws Exception {

		Mockito.when(transactionDAO.saveTransaction(Matchers.any())).thenThrow(
				new BankDataAccessException(TEST_EXCEPTION_TEXT));

		transferService.transferFunds(TransferRequest.builder()
				.reference(TRANSACTION_REFERENCE).account(CASH_ACCOUNT_1)
				.amount(Money.euros("-5.00")).account(DEPOSIT_ACCOUNT_1)
				.amount(Money.euros("5.00")).build());
	}

	@Test(expected = InfrastructureException.class)
	public void transferFundsAccountNotFoundExceptionTest() throws Exception {

		Mockito.when(accountDAO.findByAccountRef(Matchers.any())).thenReturn(
				Optional.empty());

		transferService.transferFunds(TransferRequest.builder()
				.reference(TRANSACTION_REFERENCE).account(CASH_ACCOUNT_1)
				.amount(Money.euros("-5.00")).account(DEPOSIT_ACCOUNT_1)
				.amount(Money.euros("5.00")).build());
	}

	@Test(expected = InfrastructureException.class)
	public void transferFundsInsufficientFundsExceptionTest() throws Exception {

		AccountBO accountCash = new AccountBO(CASH_ACCOUNT_1, new BigDecimal(
				"0"), EUR_CURRENCY, Calendar.getInstance());
		AccountBO accountDeposit = new AccountBO(DEPOSIT_ACCOUNT_1,
				new BigDecimal("0"), EUR_CURRENCY, Calendar.getInstance());
		Mockito.when(accountDAO.findByAccountRef(CASH_ACCOUNT_1)).thenReturn(
				Optional.of(accountCash));
		Mockito.when(accountDAO.findByAccountRef(DEPOSIT_ACCOUNT_1))
				.thenReturn(Optional.of(accountDeposit));

		transferService.transferFunds(TransferRequest.builder()
				.reference(TRANSACTION_REFERENCE).account(CASH_ACCOUNT_1)
				.amount(Money.euros("-5.00")).account(DEPOSIT_ACCOUNT_1)
				.amount(Money.euros("5.00")).build());
	}

	@Test(expected = InfrastructureException.class)
	public void transferFundsUnbalancedLegsExceptionTest() throws Exception {

		transferService.transferFunds(TransferRequest.builder()
				.reference(TRANSACTION_REFERENCE).account(CASH_ACCOUNT_1)
				.amount(Money.euros("-5.00")).account(DEPOSIT_ACCOUNT_1)
				.amount(Money.euros("5.00")).account(DEPOSIT_ACCOUNT_1)
				.amount(Money.euros("5.00")).build());
	}

	@Test
	public void transferFundsTest() throws Exception {

		AccountBO account = new AccountBO(CASH_ACCOUNT_1, BigDecimal.TEN,
				EUR_CURRENCY, Calendar.getInstance());
		Mockito.when(accountDAO.findByAccountRef(Matchers.any())).thenReturn(
				Optional.of(account));

		transferService.transferFunds(TransferRequest.builder()
				.reference(TRANSACTION_REFERENCE).account(CASH_ACCOUNT_1)
				.amount(Money.euros("-5.00")).account(DEPOSIT_ACCOUNT_1)
				.amount(Money.euros("5.00")).build());
		Mockito.verify(transactionDAO).saveTransaction(accountCaptor.capture());
		TransactionBO transactionBO = accountCaptor.getValue();

		assertNotNull(transactionBO);
		assertNotNull(transactionBO.getLegs());
		assertNotNull(transactionBO.getTransactionDate());
		assertEquals(TRANSACTION_REFERENCE, transactionBO.getReference());
		assertEquals(2, transactionBO.getLegs().size());
	}

	@Test(expected = InfrastructureException.class)
	public void findTransactionsIllegalArgumentTest() throws Exception {

		transferService.findTransactions(EMPTY_STRING);
	}

	@Test
	public void findTransactionsTest() throws Exception {

		List<TransactionBO> transactionBOList = new ArrayList<TransactionBO>();
		transactionBOList.add(transactionBO);

		Mockito.when(
				transactionDAO.findTransactionsByAccountRef(Matchers.any()))
				.thenReturn(transactionBOList);

		List<Transaction> transactionList = transferService
				.findTransactions(CASH_ACCOUNT_1);
		assertNotNull(transactionList);
		assertEquals(1, transactionList.size());
	}

	@Test(expected = InfrastructureException.class)
	public void getTransactionIllegalArgumentTest() throws Exception {

		transferService.getTransaction(EMPTY_STRING);
	}

	@Test
	public void getTransactionTest() throws Exception {

		Mockito.when(transactionDAO.findTransactionsByReference(Matchers.any()))
				.thenReturn(Optional.of(transactionBO));

		Transaction transaction = transferService
				.getTransaction(TRANSACTION_REFERENCE);
		assertNotNull(transaction);
		assertEquals(TRANSACTION_REFERENCE, transaction.getReference());
	}

	@Test
	public void getTransactionNullTest() throws Exception {

		Mockito.when(transactionDAO.findTransactionsByReference(Matchers.any()))
				.thenReturn(Optional.empty());

		Transaction transaction = transferService
				.getTransaction(TRANSACTION_REFERENCE);
		assertNull(transaction);
	}

}
