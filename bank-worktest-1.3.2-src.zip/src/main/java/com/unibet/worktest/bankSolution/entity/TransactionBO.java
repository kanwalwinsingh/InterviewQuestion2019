/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Entity class to fetch/save/update the details of the transaction request in
 * the database
 *
 * @author mohit100p29
 *
 */
@Entity
@Table(name = "transactions")
public class TransactionBO implements Serializable {

	/**
	 * Generated Serial Id
	 */
	private static final long serialVersionUID = -5251063445755829989L;

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
	@Column(name = "transaction_id")
	private Long id;

	@Column(name = "transaction_ref")
	private String reference;

	@Column(name = "type")
	private String type;

	@Column(name = "transaction_date")
	private Calendar transactionDate;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "transaction", fetch = FetchType.EAGER, orphanRemoval = true)
	private List<TransactionLegBO> legs = new ArrayList<TransactionLegBO>();

	/**
	 * Default constructor
	 */
	public TransactionBO() {
	}

	/**
	 * Parameterized constructor
	 *
	 * @param reference
	 * @param type
	 * @param transactionDate
	 */
	public TransactionBO(String reference, String type, Calendar transactionDate) {
		this.reference = reference;
		this.type = type;
		this.transactionDate = transactionDate;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the reference
	 */
	public String getReference() {
		return reference;
	}

	/**
	 * @param reference
	 *            the reference to set
	 */
	public void setReference(String reference) {
		this.reference = reference;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the transactionDate
	 */
	public Calendar getTransactionDate() {
		return transactionDate;
	}

	/**
	 * @param transactionDate
	 *            the transactionDate to set
	 */
	public void setTransactionDate(Calendar transactionDate) {
		this.transactionDate = transactionDate;
	}

	/**
	 * @return the legs
	 */
	public List<TransactionLegBO> getLegs() {
		return legs;
	}

	/**
	 * @param legs
	 *            the legs to set
	 */
	public void setLegs(List<TransactionLegBO> legs) {
		this.legs = legs;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (id == null ? 0 : id.hashCode());
		result = prime * result + (legs == null ? 0 : legs.hashCode());
		result = prime * result
				+ (reference == null ? 0 : reference.hashCode());
		result = prime * result
				+ (transactionDate == null ? 0 : transactionDate.hashCode());
		result = prime * result + (type == null ? 0 : type.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		TransactionBO other = (TransactionBO) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		if (legs == null) {
			if (other.legs != null) {
				return false;
			}
		} else if (!legs.equals(other.legs)) {
			return false;
		}
		if (reference == null) {
			if (other.reference != null) {
				return false;
			}
		} else if (!reference.equals(other.reference)) {
			return false;
		}
		if (transactionDate == null) {
			if (other.transactionDate != null) {
				return false;
			}
		} else if (!transactionDate.equals(other.transactionDate)) {
			return false;
		}
		if (type == null) {
			if (other.type != null) {
				return false;
			}
		} else if (!type.equals(other.type)) {
			return false;
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TransactionBO ["
				+ (id != null ? "id=" + id + ", " : "")
				+ (reference != null ? "reference=" + reference + ", " : "")
				+ (type != null ? "type=" + type + ", " : "")
				+ (transactionDate != null ? "transactionDate="
						+ transactionDate + ", " : "")
						+ (legs != null ? "legs=" + legs : "") + "]";
	}

}
