/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.constant;

/**
 * This interface contains all static constants used in the bank application
 *
 * @author mohit100p29
 *
 */
public interface BankSolutionConstants {

	/** Constant for base package path */
	public static final String BASE_PACKAGE_PATH = "com.unibet.worktest";

	/** Constant for entity package path */
	public static final String ENTITY_PACKAGE_PATH = "com.unibet.worktest.bankSolution.entity";
}
