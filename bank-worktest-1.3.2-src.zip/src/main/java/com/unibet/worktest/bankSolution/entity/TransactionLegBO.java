/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Entity class to fetch/save/update the details of the transaction legs in the
 * database
 *
 * @author mohit100p29
 *
 */
@Entity
@Table(name = "transaction_legs")
public class TransactionLegBO implements Serializable {

	/**
	 * Generated Serial Id
	 */
	private static final long serialVersionUID = -146641958281909960L;

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
	@Column(name = "transaction_leg_id")
	private Long id;

	@Column(name = "account_ref")
	private String accountRef;

	private BigDecimal amount;

	private String currency;

	@ManyToOne
	@JoinColumn(name = "transaction_id")
	private TransactionBO transaction;

	/**
	 * Default constructor
	 */
	public TransactionLegBO() {
	}

	/**
	 * Parameterized constructor
	 *
	 * @param accountRef
	 * @param amount
	 * @param currency
	 * @param transaction
	 */
	public TransactionLegBO(final String accountRef, final BigDecimal amount,
			final String currency, final TransactionBO transaction) {
		this.accountRef = accountRef;
		this.amount = amount;
		this.currency = currency;
		this.transaction = transaction;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the accountRef
	 */
	public String getAccountRef() {
		return accountRef;
	}

	/**
	 * @param accountRef
	 *            the accountRef to set
	 */
	public void setAccountRef(String accountRef) {
		this.accountRef = accountRef;
	}

	/**
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * @param amount
	 *            the amount to set
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency
	 *            the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the transaction
	 */
	public TransactionBO getTransaction() {
		return transaction;
	}

	/**
	 * @param transaction
	 *            the transaction to set
	 */
	public void setTransaction(TransactionBO transaction) {
		this.transaction = transaction;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ (accountRef == null ? 0 : accountRef.hashCode());
		result = prime * result + (amount == null ? 0 : amount.hashCode());
		result = prime * result + (currency == null ? 0 : currency.hashCode());
		result = prime * result + (id == null ? 0 : id.hashCode());
		result = prime * result
				+ (transaction == null ? 0 : transaction.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		TransactionLegBO other = (TransactionLegBO) obj;
		if (accountRef == null) {
			if (other.accountRef != null) {
				return false;
			}
		} else if (!accountRef.equals(other.accountRef)) {
			return false;
		}
		if (amount == null) {
			if (other.amount != null) {
				return false;
			}
		} else if (!amount.equals(other.amount)) {
			return false;
		}
		if (currency == null) {
			if (other.currency != null) {
				return false;
			}
		} else if (!currency.equals(other.currency)) {
			return false;
		}
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		if (transaction == null) {
			if (other.transaction != null) {
				return false;
			}
		} else if (!transaction.equals(other.transaction)) {
			return false;
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TransactionLegBO [" + (id != null ? "id=" + id + ", " : "")
				+ (accountRef != null ? "accountRef=" + accountRef + ", " : "")
				+ (amount != null ? "amount=" + amount + ", " : "")
				+ (currency != null ? "currency=" + currency + ", " : "")
				+ (transaction != null ? "transaction=" + transaction : "")
				+ "]";
	}

}
