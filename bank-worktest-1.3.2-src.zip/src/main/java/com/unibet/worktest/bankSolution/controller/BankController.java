/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.RestController;

import com.unibet.worktest.bankSolution.constant.BankSolutionConstants;

/**
 * This controller class contains main method for starting the spring boot
 * application
 *
 * @author mohit100p29
 *
 */
@RestController
@EnableCaching
@SpringBootApplication(scanBasePackages = { BankSolutionConstants.BASE_PACKAGE_PATH })
@EnableJpaRepositories(basePackages = { BankSolutionConstants.BASE_PACKAGE_PATH })
@EntityScan(BankSolutionConstants.ENTITY_PACKAGE_PATH)
public class BankController {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		SpringApplication.run(BankController.class, args);
	}

}
