/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

/**
 * Entity class to fetch/save/update the details of the user's account in the
 * database
 *
 * @author mohit100p29
 *
 */
@Entity
@Table(name = "account_details")
public class AccountBO implements Serializable {

	/**
	 * Generated Serial Id
	 */
	private static final long serialVersionUID = -963941774874101375L;

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
	@Column(name = "account_id")
	private Long id;

	@Column(name = "account_ref")
	private String accountReference;

	private BigDecimal balance;

	private String currency;

	@Column(name = "creation_date")
	private Calendar creationDate;

	@Column(name = "updation_date")
	private Calendar updationDate;

	/*
	 * JPA entity versioning by optimistic locking
	 */
	@Version
	private Long version;

	/**
	 * Default constructor
	 */
	public AccountBO() {
	}

	/**
	 * Parameterized constructor
	 *
	 * @param accountReference
	 * @param balance
	 * @param currency
	 * @param creationDate
	 */
	public AccountBO(String accountReference, BigDecimal balance,
			String currency, Calendar creationDate) {
		this.accountReference = accountReference;
		this.balance = balance;
		this.currency = currency;
		this.creationDate = creationDate;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the accountReference
	 */
	public String getAccountReference() {
		return accountReference;
	}

	/**
	 * @param accountReference
	 *            the accountReference to set
	 */
	public void setAccountReference(String accountReference) {
		this.accountReference = accountReference;
	}

	/**
	 * @return the balance
	 */
	public BigDecimal getBalance() {
		return balance;
	}

	/**
	 * @param balance
	 *            the balance to set
	 */
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency
	 *            the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the creationDate
	 */
	public Calendar getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate
	 *            the creationDate to set
	 */
	public void setCreationDate(Calendar creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the updationDate
	 */
	public Calendar getUpdationDate() {
		return updationDate;
	}

	/**
	 * @param updationDate
	 *            the updationDate to set
	 */
	public void setUpdationDate(Calendar updationDate) {
		this.updationDate = updationDate;
	}

	/**
	 * @return the version
	 */
	public Long getVersion() {
		return version;
	}

	/**
	 * @param version
	 *            the version to set
	 */
	public void setVersion(Long version) {
		this.version = version;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ (accountReference == null ? 0 : accountReference.hashCode());
		result = prime * result + (balance == null ? 0 : balance.hashCode());
		result = prime * result
				+ (creationDate == null ? 0 : creationDate.hashCode());
		result = prime * result + (currency == null ? 0 : currency.hashCode());
		result = prime * result + (id == null ? 0 : id.hashCode());
		result = prime * result
				+ (updationDate == null ? 0 : updationDate.hashCode());
		result = prime * result + (version == null ? 0 : version.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		AccountBO other = (AccountBO) obj;
		if (accountReference == null) {
			if (other.accountReference != null) {
				return false;
			}
		} else if (!accountReference.equals(other.accountReference)) {
			return false;
		}
		if (balance == null) {
			if (other.balance != null) {
				return false;
			}
		} else if (!balance.equals(other.balance)) {
			return false;
		}
		if (creationDate == null) {
			if (other.creationDate != null) {
				return false;
			}
		} else if (!creationDate.equals(other.creationDate)) {
			return false;
		}
		if (currency == null) {
			if (other.currency != null) {
				return false;
			}
		} else if (!currency.equals(other.currency)) {
			return false;
		}
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		if (updationDate == null) {
			if (other.updationDate != null) {
				return false;
			}
		} else if (!updationDate.equals(other.updationDate)) {
			return false;
		}
		if (version == null) {
			if (other.version != null) {
				return false;
			}
		} else if (!version.equals(other.version)) {
			return false;
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AccountBO ["
				+ (id != null ? "id=" + id + ", " : "")
				+ (accountReference != null ? "accountReference="
						+ accountReference + ", " : "")
				+ (balance != null ? "balance=" + balance + ", " : "")
				+ (currency != null ? "currency=" + currency + ", " : "")
				+ (creationDate != null ? "creationDate=" + creationDate + ", "
						: "")
				+ (updationDate != null ? "updationDate=" + updationDate + ", "
						: "") + (version != null ? "version=" + version : "")
				+ "]";
	}

}
