/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.unibet.worktest.bank.AccountNotFoundException;
import com.unibet.worktest.bank.InfrastructureException;
import com.unibet.worktest.bank.InsufficientFundsException;
import com.unibet.worktest.bank.Money;
import com.unibet.worktest.bank.Transaction;
import com.unibet.worktest.bank.TransactionLeg;
import com.unibet.worktest.bank.TransferRequest;
import com.unibet.worktest.bank.TransferService;
import com.unibet.worktest.bank.UnbalancedLegsException;
import com.unibet.worktest.bankSolution.dao.AccountDAO;
import com.unibet.worktest.bankSolution.dao.TransactionDAO;
import com.unibet.worktest.bankSolution.entity.AccountBO;
import com.unibet.worktest.bankSolution.entity.TransactionBO;
import com.unibet.worktest.bankSolution.entity.TransactionLegBO;
import com.unibet.worktest.bankSolution.exception.BankDataAccessException;

/**
 * The <code>TransferServiceImpl</code> provides implementation for
 * <code>TransferService</code> interface. It handles all logic for transaction
 * of an account.
 *
 * @author mohit100p29
 *
 */
@Service
public class TransferServiceImpl implements TransferService {

	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private TransactionDAO transactionDAO;

	@Autowired
	private AccountDAO accountDAO;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.unibet.worktest.bank.TransferService#transferFunds(com.unibet.worktest
	 * .bank.TransferRequest)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void transferFunds(TransferRequest transferRequest) {
		try {
			validateTransactionRequest(transferRequest);
			saveTransactionDetails(transferRequest);
		} catch (Exception e) {
			LOGGER.error("Error in transferring funds for transferRequest:{}",
					transferRequest, e);
			throw new InfrastructureException(
					"Error in transferring funds for transferRequest");
		}

	}

	/**
	 * This method checks the net inflow and outflow of money for all
	 * currencies, involved in a particular transaction request
	 *
	 * @param transferRequest
	 * @throws UnbalancedLegsException
	 * @throws IllegalArgumentException
	 */
	private void validateTransactionRequest(TransferRequest transferRequest) {

		List<TransactionLeg> transactionLegs = transferRequest
				.getTransactionLegs();
		Map<String, BigDecimal> currencyNetBalanceMap = new HashMap<String, BigDecimal>();

		if (!StringUtils.isEmpty(transferRequest.getReference())
				&& !CollectionUtils.isEmpty(transactionLegs)) {

			transactionLegs.stream().forEach(
					transactionLeg -> populateCurrencyNetBalanceMap(
							currencyNetBalanceMap, transactionLeg));

			for (BigDecimal currencyNetBalance : currencyNetBalanceMap.values()) {
				if (currencyNetBalance.intValue() != 0) {
					LOGGER.error("Transaction legs are not balanced, hence doesn't satisfy double-entry bookkeeping principle");
					throw new UnbalancedLegsException(
							"Transaction legs are not balanced, hence doesn't satisfy double-entry bookkeeping principle");
				}
			}
		} else {
			LOGGER.error("Transaction Request is not valid, transaction reference and Legs can't be empty");
			throw new IllegalArgumentException(
					"Transaction Request is not valid, transaction reference and Legs can't be empty");
		}
	}

	/**
	 * This function populates the Map having currency as key and sum of all
	 * transaction amount for that currency as value
	 *
	 * @param currencyNetBalanceMap
	 * @param transactionLeg
	 */
	private void populateCurrencyNetBalanceMap(
			Map<String, BigDecimal> currencyNetBalanceMap,
			TransactionLeg transactionLeg) {

		Money transactionMoney = transactionLeg.getAmount();
		if (currencyNetBalanceMap.containsKey(transactionMoney.getCurrency()
				.getCurrencyCode())) {
			BigDecimal currencyNetBalance = currencyNetBalanceMap
					.get(transactionMoney.getCurrency().getCurrencyCode());
			currencyNetBalanceMap.put(transactionMoney.getCurrency()
					.getCurrencyCode(), currencyNetBalance.add(transactionMoney
							.getAmount()));
		} else {
			currencyNetBalanceMap.put(transactionMoney.getCurrency()
					.getCurrencyCode(), transactionMoney.getAmount());
		}
	}

	/**
	 * This method checks the Account current balance if sufficient populates
	 * {@link TransactionBO} from {@link TransferRequest} and saves the
	 * transaction and account details in the database
	 *
	 * @param transferRequest
	 * @throws AccountNotFoundException
	 * @throws InsufficientFundsException
	 * @throws InfrastructureException
	 */
	private void saveTransactionDetails(TransferRequest transferRequest) {

		try {
			TransactionBO transactionBO = new TransactionBO(
					transferRequest.getReference(), transferRequest.getType(),
					Calendar.getInstance());

			Map<String, AccountBO> accountsMap = new HashMap<String, AccountBO>();
			List<TransactionLegBO> transactionLegBOList = new ArrayList<TransactionLegBO>();
			transferRequest
			.getTransactionLegs()
			.stream()
			.forEach(
					transactionLeg -> populateTransactionLegList(
							transactionLeg, accountsMap,
							transactionLegBOList, transactionBO));

			transactionBO.setLegs(transactionLegBOList);
			transactionDAO.saveTransaction(transactionBO);
			accountDAO.updateAccounts(new ArrayList<AccountBO>(accountsMap
					.values()));
		} catch (BankDataAccessException e) {
			LOGGER.error("Error in transferring funds for transferRequest:{}",
					transferRequest, e);
			throw new InfrastructureException(
					"Error in transferring funds for transferRequest");
		}
	}

	/**
	 * This method populates the List of {@link TransactionLegBO} and also
	 * populates Map of {@link AccountBO} to be updated in the database. This
	 * method also verifies if the account has sufficient balance for the
	 * transaction or not.
	 *
	 * @param transactionLeg
	 * @param accountsMap
	 * @param transactionLegBOList
	 * @param transactionBO
	 */
	private void populateTransactionLegList(TransactionLeg transactionLeg,
			Map<String, AccountBO> accountsMap,
			List<TransactionLegBO> transactionLegBOList,
			TransactionBO transactionBO) {

		try {
			Money transactionMoney = transactionLeg.getAmount();
			AccountBO account = null;
			if (accountsMap.containsKey(transactionLeg.getAccountRef())) {
				account = accountsMap.get(transactionLeg.getAccountRef());
			} else {
				account = accountDAO.findByAccountRef(
						transactionLeg.getAccountRef()).orElse(null);
				if (account == null) {
					LOGGER.error(
							"Error getting Account details, account not found for accountRef:{}",
							transactionLeg.getAccountRef());
					throw new AccountNotFoundException(
							transactionLeg.getAccountRef());
				}
			}
			account.setBalance(account.getBalance().add(
					transactionMoney.getAmount()));
			account.setUpdationDate(Calendar.getInstance());
			if (account.getBalance().compareTo(BigDecimal.ZERO) == -1) {
				LOGGER.error(
						"Funds are not sufficient for transaction in account:{}, for transaction amount:{}",
						account, transactionMoney.getAmount());
				throw new InsufficientFundsException(
						"Funds are not sufficient for transaction in account for transaction amount");
			}
			accountsMap.put(transactionLeg.getAccountRef(), account);

			TransactionLegBO transactionLegBO = new TransactionLegBO(
					transactionLeg.getAccountRef(), transactionLeg.getAmount()
							.getAmount(), transactionLeg.getAmount()
							.getCurrency().getCurrencyCode(), transactionBO);
			transactionLegBOList.add(transactionLegBO);
		} catch (BankDataAccessException e) {
			LOGGER.error("Error in transferring funds for transactionLeg",
					transactionLeg, e);
			throw new InfrastructureException(
					"Error in transferring funds for transferRequest");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.unibet.worktest.bank.TransferService#findTransactions(java.lang.String
	 * )
	 */
	@Override
	@Cacheable("transactionsListByAccount")
	public List<Transaction> findTransactions(String accountRef) {
		List<Transaction> transactionList = null;
		try {
			if (StringUtils.isNotEmpty(accountRef)) {
				List<TransactionBO> transactionBOList = transactionDAO
						.findTransactionsByAccountRef(accountRef);

				if (!CollectionUtils.isEmpty(transactionBOList)) {

					transactionList = transactionBOList
							.stream()
							.map(transactionBO -> populateTransaction(transactionBO))
							.collect(Collectors.toList());
				}
			} else {
				LOGGER.error("Error getting transaction, accountRef can't be empty");
				throw new InfrastructureException(
						"Error getting transaction, accountRef can't be empty");
			}
		} catch (BankDataAccessException e) {
			LOGGER.error("Error getting transaction details by accountRef: {}",
					accountRef, e);
			throw new InfrastructureException(
					"Error getting transaction details by accountRef: "
							+ accountRef);
		}
		return transactionList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.unibet.worktest.bank.TransferService#getTransaction(java.lang.String)
	 */
	@Override
	@Cacheable("transactionByReference")
	public Transaction getTransaction(String transactionRef) {

		Transaction transaction = null;
		try {
			if (StringUtils.isNotEmpty(transactionRef)) {
				Optional<TransactionBO> transactionBO = transactionDAO
						.findTransactionsByReference(transactionRef);
				if (transactionBO.isPresent()) {
					transaction = populateTransaction(transactionBO.get());
				}
			} else {
				LOGGER.error("Error getting transaction details, transactionRef can't be empty");
				throw new InfrastructureException(
						"Error getting transaction details, transactionRef can't be empty");
			}
		} catch (BankDataAccessException e) {
			LOGGER.error(
					"Error getting transaction details by transactionRef: {}",
					transactionRef, e);
			throw new InfrastructureException(
					"Error getting transaction details by transactionRef: "
							+ transactionRef);
		}
		return transaction;
	}

	/**
	 * This method populates the {@link Transaction} object from
	 * {@link TransactionBO}
	 *
	 * @param transactionBO
	 *            - Instance of {@link TransactionBO}
	 *
	 * @return {@link Transaction}
	 */
	private Transaction populateTransaction(TransactionBO transactionBO) {

		List<TransactionLeg> transactionLegList = transactionBO
				.getLegs()
				.stream()
				.map(transactionLegBO -> new TransactionLeg(transactionLegBO
						.getAccountRef(),
						Money.create(transactionLegBO.getAmount().toString(),
								transactionLegBO.getCurrency())))
								.collect(Collectors.toList());

		return new Transaction(transactionBO.getReference(),
				transactionBO.getType(), transactionBO.getTransactionDate()
				.getTime(), transactionLegList);
	}

}
