/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.dao;

import java.util.List;
import java.util.Optional;

import com.unibet.worktest.bankSolution.entity.TransactionBO;
import com.unibet.worktest.bankSolution.exception.BankDataAccessException;

/**
 * The <code>TransactionDAO</code> contains the methods required for Transaction
 * Requests to interact with database. It internally uses Spring DATA JPA API,
 * to create normal CRUD operations. API's includes saving a transaction,
 * finding transactions by account reference, etc.
 *
 * @author mohit100p29
 *
 */
public interface TransactionDAO {

	/**
	 * This method persists the transaction and its corresponding legs in the
	 * database
	 *
	 * @param transaction
	 * @return {@link TransactionBO}
	 * @throws BankDataAccessException
	 */
	public TransactionBO saveTransaction(TransactionBO transaction)
			throws BankDataAccessException;

	/**
	 * This method fetches the list of all transaction corresponding to specific
	 * account reference
	 *
	 * @param accountRef
	 * @return List of {@link TransactionBO}
	 * @throws BankDataAccessException
	 */
	public List<TransactionBO> findTransactionsByAccountRef(String accountRef)
			throws BankDataAccessException;

	/**
	 * This method fetches the transaction details corresponding to transaction
	 * reference
	 *
	 * @param transactionRef
	 * @return Optional {@link TransactionBO}
	 * @throws BankDataAccessException
	 */
	public Optional<TransactionBO> findTransactionsByReference(
			String transactionRef) throws BankDataAccessException;
}
