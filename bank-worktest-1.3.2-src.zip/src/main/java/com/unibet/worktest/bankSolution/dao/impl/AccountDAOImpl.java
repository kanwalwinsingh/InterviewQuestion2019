/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.dao.impl;

import java.util.List;
import java.util.Optional;

import javax.persistence.PersistenceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.unibet.worktest.bankSolution.dao.AccountDAO;
import com.unibet.worktest.bankSolution.entity.AccountBO;
import com.unibet.worktest.bankSolution.exception.BankDataAccessException;
import com.unibet.worktest.bankSolution.repositories.AccountRepository;

/**
 * The <code>AccountDAOImpl</code> provides implementation of {@link AccountDAO}
 * for database operations for a {@link AccountBO} entity.
 *
 * @author mohit100p29
 *
 */
@Repository
public class AccountDAOImpl implements AccountDAO {

	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private AccountRepository accountRepository;

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.unibet.worktest.bankSolution.dao.AccountDAO#saveAccount(com.unibet
	 * .worktest.bankSolution.entity.Account)
	 */
	@Override
	public AccountBO saveAccount(AccountBO account)
			throws BankDataAccessException {
		try {
			return accountRepository.save(account);
		} catch (PersistenceException | DataAccessException e) {
			LOGGER.error("Error while saving account details : {}", account, e);
			throw new BankDataAccessException(
					"Error while saving account details : " + account, e);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.unibet.worktest.bankSolution.dao.AccountDAO#findByAccountRef(java
	 * .lang.String)
	 */
	@Override
	public Optional<AccountBO> findByAccountRef(String accountRef)
			throws BankDataAccessException {
		try {
			return accountRepository.findByAccountReference(accountRef);
		} catch (PersistenceException | DataAccessException e) {
			LOGGER.error(
					"Error while finding account details by accountRef: {}",
					accountRef, e);
			throw new BankDataAccessException(
					"Error while fetching account details by accountRef: "
							+ accountRef, e);
		}
	}

	@Override
	public void updateAccounts(List<AccountBO> accounts)
			throws BankDataAccessException {
		try {
			accountRepository.save(accounts);
		} catch (PersistenceException | DataAccessException e) {
			LOGGER.error("Error while updating account details", e);
			throw new BankDataAccessException(
					"Error while updating account details", e);
		}
	}

}
