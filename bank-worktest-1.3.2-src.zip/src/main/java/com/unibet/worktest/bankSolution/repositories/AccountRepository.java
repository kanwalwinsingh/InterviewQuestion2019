/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.unibet.worktest.bankSolution.entity.AccountBO;

/**
 * The Interface {@code AccountRepository} is used for DB operating related to
 * account.
 *
 * @author mohit100p29
 *
 */
@Repository
public interface AccountRepository extends JpaRepository<AccountBO, Long> {

	/**
	 * Gets the Account by its accountReference
	 *
	 * @param accountReference
	 * @return Optional of {@link AccountBO}
	 */
	public Optional<AccountBO> findByAccountReference(String accountReference);

}
