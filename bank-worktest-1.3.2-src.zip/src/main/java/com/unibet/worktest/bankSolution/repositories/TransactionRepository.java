/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.unibet.worktest.bankSolution.entity.TransactionBO;

/**
 * The Interface TransactionRepository is used for DB operating related to
 * transactions.
 *
 * @author mohit100p29
 *
 */
@Repository
public interface TransactionRepository extends
		JpaRepository<TransactionBO, Long> {

	/**
	 * Gets the List of Transactions by accountReference
	 *
	 * @param accountRef
	 * @return List of {@link TransactionBO}
	 */
	@Query("select distinct t from TransactionBO t join t.legs l where l.accountRef = :accountRef ")
	public List<TransactionBO> findTransactionsByAccountRef(
			@Param("accountRef") final String accountRef);

	/**
	 * Gets the Transaction details by its reference number
	 *
	 * @param transactionRef
	 * @return Optional of {@link TransactionBO}
	 */
	public Optional<TransactionBO> findTransactionsByReference(
			String transactionRef);
}
