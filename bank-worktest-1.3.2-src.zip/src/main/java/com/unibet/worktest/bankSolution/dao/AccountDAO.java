/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.dao;

import java.util.List;
import java.util.Optional;

import com.unibet.worktest.bankSolution.entity.AccountBO;
import com.unibet.worktest.bankSolution.exception.BankDataAccessException;

/**
 * The <code>AccountDAO</code> contains the methods required for Account
 * Requests to interact with database. It internally uses Spring DATA JPA API,
 * to create normal CRUD operations. API's includes saving a new account,
 * finding account by account reference, updating balance of the account, etc.
 *
 * @author mohit100p29
 *
 */
public interface AccountDAO {

	/**
	 * This method saves a new account details in the database
	 *
	 * @param account
	 * @return {@link AccountBO}
	 * @throws BankDataAccessException
	 */
	public AccountBO saveAccount(AccountBO account)
			throws BankDataAccessException;

	/**
	 * This method returns Account details corresponding to account reference if
	 * present
	 *
	 * @param accountRef
	 * @return Optional of {@link AccountBO}
	 * @throws BankDataAccessException
	 */
	public Optional<AccountBO> findByAccountRef(String accountRef)
			throws BankDataAccessException;

	/**
	 * This method updates the list of account passed to it
	 *
	 * @param accounts
	 *            - List of accounts to be updated
	 * @throws BankDataAccessException
	 */
	public void updateAccounts(List<AccountBO> accounts)
			throws BankDataAccessException;

}
