/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.service.impl;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Currency;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unibet.worktest.bank.AccountNotFoundException;
import com.unibet.worktest.bank.AccountService;
import com.unibet.worktest.bank.InfrastructureException;
import com.unibet.worktest.bank.Money;
import com.unibet.worktest.bankSolution.dao.AccountDAO;
import com.unibet.worktest.bankSolution.entity.AccountBO;
import com.unibet.worktest.bankSolution.exception.BankDataAccessException;

/**
 * The <code>AccountServiceImpl</code> provides implementation for
 * <code>AccountService</code> interface. It handles all logic for user account.
 *
 * @author mohit100p29
 *
 */
@Service
public class AccountServiceImpl implements AccountService {

	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

	/*
	 * Minimum balance for opening an account
	 */
	private static final BigDecimal MINIMUM_ACCOUNT_BALANCE = BigDecimal.ZERO;

	@Autowired
	private AccountDAO accountDAO;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.unibet.worktest.bank.AccountService#createAccount(java.lang.String,
	 * com.unibet.worktest.bank.Money)
	 */
	@Override
	public void createAccount(String accountRef, Money amount) {

		try {
			if (isAccountValid(accountRef, amount)) {
				AccountBO account = new AccountBO(accountRef,
						amount.getAmount(), amount.getCurrency()
								.getCurrencyCode(), Calendar.getInstance());
				accountDAO.saveAccount(account);
			} else {
				LOGGER.error("Error creating new Account, account details are not valid");
				throw new InfrastructureException(
						"Error creating new Account, account details are not valid");
			}
		} catch (BankDataAccessException e) {
			LOGGER.error(
					"Error creating new Account for accountRef{}, amount {}",
					accountRef, amount, e);
			throw new InfrastructureException("Error creating new Account");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.unibet.worktest.bank.AccountService#getAccountBalance(java.lang.String
	 * )
	 */
	@Override
	public Money getAccountBalance(String accountRef) {
		Money money = null;
		try {
			if (StringUtils.isNotEmpty(accountRef)) {
				Optional<AccountBO> accountOptional = accountDAO
						.findByAccountRef(accountRef);
				if (accountOptional.isPresent()) {
					Currency accountCurrency = Currency
							.getInstance(accountOptional.get().getCurrency());
					money = Money.create(accountOptional.get().getBalance()
							.toString(), accountCurrency);
				} else {
					LOGGER.error(
							"Error getting Account details, account not found for accountRef:{}",
							accountRef);
					throw new AccountNotFoundException(accountRef);
				}
			} else {
				LOGGER.error("Error getting Account details, account reference number can't be empty");
				throw new InfrastructureException(
						"Error getting Account details, account reference number can't be empty");
			}
		} catch (BankDataAccessException e) {
			LOGGER.error("Error getting Account details for accountRef:{}",
					accountRef, e);
			throw new InfrastructureException(
					"Error getting Account details for accountRef" + accountRef);
		}
		return money;
	}

	/**
	 * This method checks if the details for opening an account are valid or not
	 *
	 * @param accountRef
	 * @param money
	 * @return true if valid
	 */
	private boolean isAccountValid(String accountRef, Money money) {
		boolean isValid = true;
		if (StringUtils.isEmpty(accountRef)) {
			isValid = false;
			LOGGER.error("Error account reference number can't be empty");
		} else if (!Optional.ofNullable(money).map(Money::getAmount)
				.isPresent()
				|| money.getAmount().compareTo(MINIMUM_ACCOUNT_BALANCE) == -1) {
			isValid = false;
			LOGGER.error("Error money can't be empty or less than {}",
					MINIMUM_ACCOUNT_BALANCE);
		}

		return isValid;
	}
}
