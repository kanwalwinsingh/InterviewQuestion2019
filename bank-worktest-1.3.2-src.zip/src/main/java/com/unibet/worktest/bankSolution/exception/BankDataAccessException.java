/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.exception;

/**
 * This class represents Bank DataAccess exception. All dao classes will wrap
 * any exception in BankDataAccessException and throw it to service layer.
 *
 * @author mohit100p29
 *
 */
public class BankDataAccessException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = -1569655673697565778L;

	/**
	 * No-arg Constructor.
	 */
	public BankDataAccessException() {
		super();
	}

	/**
	 * Instantiates a new bank data access exception.
	 *
	 * @param message
	 *            the message
	 */
	public BankDataAccessException(final String message) {
		super(message);
	}

	/**
	 * Constructor which takes Throwable class instance.
	 *
	 * @param originalException
	 *            the throwable original exception
	 */
	public BankDataAccessException(final Throwable originalException) {
		super(originalException);
	}

	/**
	 * Instantiates a new bank data access exception.
	 *
	 * @param originalException
	 *            the original exception
	 * @param message
	 *            the message
	 */
	public BankDataAccessException(final String message,
			final Throwable originalException) {
		super(message, originalException);
	}

}
