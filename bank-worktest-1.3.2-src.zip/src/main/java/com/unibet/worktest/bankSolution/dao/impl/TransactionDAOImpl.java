/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bankSolution.dao.impl;

import java.util.List;
import java.util.Optional;

import javax.persistence.PersistenceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.unibet.worktest.bankSolution.dao.TransactionDAO;
import com.unibet.worktest.bankSolution.entity.TransactionBO;
import com.unibet.worktest.bankSolution.exception.BankDataAccessException;
import com.unibet.worktest.bankSolution.repositories.TransactionRepository;

/**
 * The <code>TransactionDAOImpl</code> provides implementation of
 * {@link TransactionDAO} for database operations for a {@link TransactionBO}
 * entity.
 *
 * @author mohit100p29
 *
 */
@Repository
public class TransactionDAOImpl implements TransactionDAO {

	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private TransactionRepository transactionRepository;

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.unibet.worktest.bankSolution.dao.TransactionDAO#saveTransaction(com
	 * .unibet.worktest.bankSolution.entity.TransactionBO)
	 */
	@Override
	public TransactionBO saveTransaction(TransactionBO transaction)
			throws BankDataAccessException {
		try {
			return transactionRepository.save(transaction);
		} catch (PersistenceException | DataAccessException e) {
			LOGGER.error("Error while saving transaction details : {}",
					transaction, e);
			throw new BankDataAccessException(
					"Error while saving transaction details : " + transaction,
					e);
		}
	}

	@Override
	public List<TransactionBO> findTransactionsByAccountRef(String accountRef)
			throws BankDataAccessException {
		try {
			return transactionRepository
					.findTransactionsByAccountRef(accountRef);
		} catch (PersistenceException | DataAccessException e) {
			LOGGER.error(
					"Error while fetching the transaction details by accountRef: "
							+ accountRef, e);
			throw new BankDataAccessException(
					"Error while fetching the transaction details by accountRef: "
							+ accountRef, e);
		}
	}

	@Override
	public Optional<TransactionBO> findTransactionsByReference(
			String transactionRef) throws BankDataAccessException {
		try {
			return transactionRepository
					.findTransactionsByReference(transactionRef);
		} catch (PersistenceException | DataAccessException e) {
			LOGGER.error(
					"Error while fetching the transaction details by transactionRef : "
							+ transactionRef, e);
			throw new BankDataAccessException(
					"Error while fetching the transaction details by transactionRef : "
							+ transactionRef, e);
		}
	}

}
