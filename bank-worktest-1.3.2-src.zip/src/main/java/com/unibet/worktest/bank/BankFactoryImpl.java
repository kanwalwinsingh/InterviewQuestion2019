/**
 *
 * This file is part of bank-worktest project.
 *
 * Revision: 1.0, last modified: 2017
 *
 */
package com.unibet.worktest.bank;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.unibet.worktest.bankSolution.controller.BankController;

/**
 * The <code>BankFactoryImpl</code> provides implementation for
 * <code>BankFactory</code> interface. It provides method to get object of
 * service classes.
 * 
 * @author mohit100p29
 *
 */
public class BankFactoryImpl implements BankFactory {

	private AnnotationConfigApplicationContext context = null;

	public BankFactoryImpl() {
		context = new AnnotationConfigApplicationContext(BankController.class);
	}

	@Override
	public AccountService getAccountService() {
		return context.getBean(AccountService.class);
	}

	@Override
	public TransferService getTransferService() {
		return context.getBean(TransferService.class);
	}

	@Override
	public void setupInitialData() {
		// TODO Auto-generated method stub

	}

}
